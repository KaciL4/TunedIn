﻿using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;

namespace TunedIn.ViewModels
{
    public enum ViewType { Library, Playlists, NowPlaying }
    public partial class MainWindowViewModel : ViewModelBase
    {
        // Lists (Use ObservableCollection for automatic UI updates)
        public ObservableCollection<Song> Songs { get; } = new ObservableCollection<Song>();
        public ObservableCollection<Playlist> Playlists { get; } = new ObservableCollection<Playlist>();
        public ObservableCollection<Song> Queue { get; } = new ObservableCollection<Song>();

        private ViewType _currentView = ViewType.Library;
        public ViewType CurrentView
        {
            get => _currentView;
            set => Set(ref _currentView, value);
        }

        private Song _currentSong;
        public Song CurrentSong
        {
            get => _currentSong;
            set => Set(ref _currentSong, value);
        }

        private bool _isPlaying;
        public bool IsPlaying
        {
            get => _isPlaying;
            set => Set(ref _isPlaying, value);
        }

        private double _currentTime;
        public double CurrentTime
        {
            get => _currentTime;
            set => Set(ref _currentTime, value);
        }

        private double _volume = 1.0; // Corresponds to React's setVolume(1)
        public double Volume
        {
            get => _volume;
            set
            {
                if (Set(ref _volume, value))
                {
                    // Update the media player's volume here
                    // _mediaPlayerService.SetVolume(value);
                }
            }
        }

        private bool _repeat;
        public bool Repeat
        {
            get => _repeat;
            set => Set(ref _repeat, value);
        }

        private int _currentQueueIndex;
        public int CurrentQueueIndex
        {
            get => _currentQueueIndex;
            set => Set(ref _currentQueueIndex, value);
        }

        // ----------------------------------------------------
        // Commands (Replacing React Event Handlers: onTogglePlayPause, onNext, etc.)
        // ----------------------------------------------------
        public ICommand ChangeViewCommand { get; }
        public ICommand TogglePlayPauseCommand { get; }
        public ICommand NextCommand { get; }
        public ICommand PreviousCommand { get; }
        public ICommand SeekCommand { get; }
        public ICommand ToggleRepeatCommand { get; }
        public ICommand AddSongsCommand { get; }
        public ICommand RemoveSongCommand { get; }
        public ICommand PlaySongCommand { get; }
        // ... You would also define commands for PlaylistManager (Create, Delete, etc.)

        public MainWindowViewModel()
        {
            // Initialize commands. A real app would use a library like ReactiveUI for this.
            // For a basic structure, assume a simple RelayCommand class exists.

            // UI Navigation
            ChangeViewCommand = new RelayCommand<ViewType>(view => CurrentView = view);

            // Player Controls
            TogglePlayPauseCommand = new RelayCommand(TogglePlayPause);
            NextCommand = new RelayCommand(HandleNext, CanSkip);
            PreviousCommand = new RelayCommand(HandlePrevious, CanSkip);
            SeekCommand = new RelayCommand<double>(HandleSeek);
            ToggleRepeatCommand = new RelayCommand(() => Repeat = !Repeat);

            // Library/Data Management
            AddSongsCommand = new RelayCommand(ImportSongs);
            RemoveSongCommand = new RelayCommand<string>(RemoveSong);
            PlaySongCommand = new RelayCommand<Song>(song => PlaySong(song, Songs.ToList(), Songs.IndexOf(song)));

            // Simulate initial data load (optional)
            LoadInitialData();
        }

        // ----------------------------------------------------
        // Methods (Replacing React Functions)
        // ----------------------------------------------------

        // Helper for simulating initial data
        private void LoadInitialData()
        {
            Songs.Add(new Song { Id = "s1", Title = "Test Song 1", Artist = "Artist A", Duration = 180.5, FilePath = "C:/music/s1.mp3" });
            Songs.Add(new Song { Id = "s2", Title = "Another Track", Artist = "Artist B", Duration = 245.0, FilePath = "C:/music/s2.mp3" });

            Playlists.Add(new Playlist { Id = "p1", Name = "Favorites", CreatedAt = DateTime.Now, SongIds = { "s1" } });

            if (Songs.Any())
            {
                // Set a default song for the player to display
                CurrentSong = Songs.First();
            }
        }

        // --- Player Logic ---
        private void TogglePlayPause()
        {
            if (CurrentSong == null) return;

            IsPlaying = !IsPlaying;
            // The actual Play/Pause logic for the C# media player would go here:
            // if (IsPlaying) _mediaPlayerService.Play(); else _mediaPlayerService.Pause();
        }

        private bool CanSkip() => CurrentSong != null;

        private void HandleNext()
        {
            if (Queue.Count == 0 || CurrentSong == null) return;

            int nextIndex = CurrentQueueIndex + 1;

            if (Repeat && nextIndex >= Queue.Count)
            {
                nextIndex = 0; // Loop back to the start if repeat is enabled
            }

            if (nextIndex < Queue.Count)
            {
                PlaySong(Queue[nextIndex], Queue.ToList(), nextIndex);
            }
            else
            {
                // Stop playback if at the end and not repeating
                IsPlaying = false;
                // _mediaPlayerService.Stop();
            }
        }

        private void HandlePrevious()
        {
            if (Queue.Count == 0 || CurrentSong == null) return;

            // Check if we are early in the song (e.g., less than 3 seconds)
            if (CurrentTime > 3.0)
            {
                HandleSeek(0.0); // Restart current song
            }
            else
            {
                int previousIndex = CurrentQueueIndex - 1;

                if (previousIndex >= 0)
                {
                    PlaySong(Queue[previousIndex], Queue.ToList(), previousIndex);
                }
            }
        }

        private void HandleSeek(double newTime)
        {
            CurrentTime = newTime;
            // Seek logic for C# media player:
            // _mediaPlayerService.SeekTo(newTime);
        }

        public void PlaySong(Song song, List<Song> newQueue, int indexInQueue)
        {
            CurrentSong = song;
            // Update queue state
            Queue.Clear();
            foreach (var item in newQueue) Queue.Add(item);
            CurrentQueueIndex = indexInQueue;

            // Start playback
            IsPlaying = true;
            // Logic to load and start the song using a C# media library:
            // _mediaPlayerService.Load(song.FilePath);
            // _mediaPlayerService.Play();
        }


        // --- Library Management ---

        // Replaces the logic in handleFileSelect and addSongs
        public async void ImportSongs()
        {
            // In Avalonia, you would use a service to open a file dialog,
            // e.g., using IStorageProvider or a custom dialog service.

            // The result of the dialog would be file paths (string[]).
            // Example of adding a new song:
            // foreach (string filePath in filePaths)
            // {
            //     // Use a C# library like TagLib# to read metadata (title, artist, duration)
            //     var newSong = new Song 
            //     { 
            //         Id = Guid.NewGuid().ToString(), 
            //         Title = "New Imported Song", 
            //         Artist = "Unknown",
            //         Duration = 200.0,
            //         FilePath = filePath 
            //     };
            //     Songs.Add(newSong);
            // }
            // The logic from App.tsx's toast.success would be done here using a C# Notification system.
        }

        public void RemoveSong(string songId)
        {
            var songToRemove = Songs.FirstOrDefault(s => s.Id == songId);
            if (songToRemove != null)
            {
                Songs.Remove(songToRemove);
                // Also remove from any playlists and update queue logic
            }
        }

        // --- Utility ---
        public string FormatTime(double seconds)
        {
            var timeSpan = TimeSpan.FromSeconds(seconds);
            return timeSpan.ToString(@"m\:ss");
        }
    }
}
