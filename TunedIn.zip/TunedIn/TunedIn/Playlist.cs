﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TunedIn
{
    public class Playlist
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public List<string> SongIds { get; set; } = new List<string>();
        public long CreatedAt { get; set; }
    }
}
